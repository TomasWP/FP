# Example: if statements.

N = int(input("N? "))

if N > 10:
    print("A")

if N % 2 == 0:
    print("B")

print("END")
