# Example: A simple if-else statement.

idade = int(input("idade? "))

print(idade)

if idade >= 18:
    res = "OK"
    print("MAIOR")
else: 
    res = "KO"

print(res)
print("FIM")
