# Example: if statements.

N = int(input("N? "))

if N > 10:
    print("A")

if N < 20:
    print("B")

print("END")
