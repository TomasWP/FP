def tax(r):
	if r<=1000:
		r=0.1*r
		return r
	elif r<=2000:
		r=0.2*r-100
		return r
	else:
		r=0.3*r-300
		return r
r=float(input("Qual valor deseja que r tome? "))
res=tax(r)
print (res)

