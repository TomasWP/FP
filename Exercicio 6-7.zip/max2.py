def max2(x1,x2):
		if x1>x2:
			return x1
		else:
			return x2
def max3(m2,x3):
	if (m2)>x3:
		return (m2)
	else:
		return x3
num=int(input("Pretende ver o maior número para 2 ou 3 argumentos? "))
if num==2 or num==3:
	if num==2:
		x1 = float(input("Por favor insira o 1º número: "))
		x2 = float(input("Por favor insira o 2º número: "))
		m2=max2(x1,x2)
		print ("O maior dos 2 números é: ",m2)
	else:
		x1 = float(input("Por favor insira o 1º número: "))
		x2 = float(input("Por favor insira o 2º número: "))
		x3 = float(input("Por favor insira o 3º número: "))
		m2=max2(x1,x2)
		m3=max3(m2,x3)
		print ("O maior dos 3 números é: ",m3)

else:
	print ("ERROR!Por favor insira o número 2 ou 3!")
