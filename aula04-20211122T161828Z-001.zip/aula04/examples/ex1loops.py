# Example: the while iterative statement
# JMR 2018

def main():
    n = 3
    while n > 0:
        print("ola")
        # This will run forever.  Can you fix it?
    print("FIM")

# Call main
main()

